DONATIX = DONATIX or {}
DONATIX.Config = DONATIX.Config or {}
DONATIX.ItemsList = DONATIX.ItemsList or {}

function DONATIX:AddItem(unique_id)
    local item = { 
        ID = unique_id, 
        Price = 0, 
        Name = "Невідомий предмет", 
        Category = "Різне",
        Term = 0, -- 0 = назавжди або до виходу
        Stackable = false
    }
    
    function item:SetName(v) self.Name = v return self end
    function item:SetPrice(v) self.Price = v return self end
    function item:SetDescription(v) self.Desc = v return self end
    function item:SetTerm(v) self.Term = v return self end
    function item:SetPerma() self.Term = 0 return self end
    function item:SetStackable(v) self.Stackable = v return self end
    function item:SetIcon(v, isModel) self.Icon = v; self.IsModel = isModel return self end
    function item:SetCategory(v) self.Category = v return self end
    function item:SetDiscountedFrom(v) self.DiscountedFrom = v return self end
    function item:SetCanActivate(v) self.CanActivate = v return self end
    function item:SetCanBuy(v) self.CanBuy = v return self end
    function item:SetOnActivate(v) self.OnActivate = v return self end
    function item:SetMaxGlobalPurchases(v) self.MaxGlobal = v return self end
    function item:SetMaxPlayerPurchases(v) self.MaxPlayer = v return self end
    function item:SetRandom(v) self.RandomItems = v return self end
    function item:SetItems(v) self.PackItems = v return self end
    function item:SetGlobal(v) self.IsGlobal = v return self end
    function item:AddHook(h, cb) self.Hooks = self.Hooks or {}; self.Hooks[h] = cb return self end
    function item:SetGetPrice(v) self.GetPriceFunc = v return self end
    function item:SetNetworked(v) self.Networked = v return self end
    function item:SetImage(v) self.Image = v return self end
    function item:SetCanSee(v) self.CanSee = v return self end
    function item:SetInstaller(v) self.Installer = v return self end
    function item:SetValidator(v) self.Validator = v return self end
    function item:SetHighlightColor(v) self.HighlightColor = v return self end
    function item:SetCommand(v) self.Command = v return self end

    table.insert(self.ItemsList, item)
    return item
end

function DONATIX:GetItemByID(id)
    for _, item in ipairs(self.ItemsList) do
        if item.ID == id then return item end
    end
    return nil
end


if SERVER then
    AddCSLuaFile("donatix/sh_config.lua")
    AddCSLuaFile("donatix/sh_items.lua")
    AddCSLuaFile("donatix/cl_menu.lua")

    include("donatix/sh_config.lua")
    include("donatix/sh_items.lua")
    include("donatix/sv_api.lua")
else
    include("donatix/sh_config.lua")
    include("donatix/sh_items.lua")
    include("donatix/cl_menu.lua")
end