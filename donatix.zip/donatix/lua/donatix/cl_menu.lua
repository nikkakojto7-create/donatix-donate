local localBalance = 0
local localInventory = {}
local activeCategory = "Усі"

local OpenDonateMenu

net.Receive("Donatix_SyncData", function()
    localBalance = net.ReadUInt(32)
    local invStr = net.ReadString()
    localInventory = util.JSONToTable(invStr) or {}
    
    if IsValid(DonatixMainFrame) then
        local x, y = DonatixMainFrame:GetPos()
        DonatixMainFrame:Close()
        OpenDonateMenu()
        if IsValid(DonatixMainFrame) then DonatixMainFrame:SetPos(x, y) end
    end
end)

net.Receive("Donatix_Notify", function()
    local msg = net.ReadString()
    local isErr = net.ReadBool()
    chat.AddText(isErr and Color(255, 0, 0) or Color(46, 204, 113), "[DONATIX] ", Color(255, 255, 255), msg)
end)

net.Receive("Donatix_OpenURL", function() gui.OpenURL(net.ReadString()) end)

OpenDonateMenu = function()
    if IsValid(DonatixMainFrame) then DonatixMainFrame:Close() end

    local colorBg = Color(245, 247, 250)
    local colorWhite = Color(255, 255, 255)
    local colorBlue = Color(41, 128, 185)
    local colorDark = Color(44, 62, 80)
    local colorGray = Color(149, 165, 166)

    DonatixMainFrame = vgui.Create("DFrame")
    local f = DonatixMainFrame
    f:SetSize(1000, 650)
    f:Center()
    f:SetTitle("")
    f:ShowCloseButton(false)
    f:MakePopup()
    f.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, colorBg)
    end

    local closeBtn = vgui.Create("DButton", f)
    closeBtn:SetPos(f:GetWide() - 40, 10)
    closeBtn:SetSize(30, 30)
    closeBtn:SetText("✕")
    closeBtn:SetFont("Trebuchet24")
    closeBtn:SetTextColor(colorGray)
    closeBtn.Paint = function() end
    closeBtn.DoClick = function() f:Close() end

    -- ПРАВА ПАНЕЛЬ (Профіль та Інвентар)
    local rightPanel = vgui.Create("DPanel", f)
    rightPanel:Dock(RIGHT)
    rightPanel:SetWide(260)
    rightPanel:DockMargin(10, 40, 10, 10)
    rightPanel.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, colorWhite)
        draw.RoundedBoxEx(8, 0, 0, w, 140, colorBlue, true, true, false, false)
    end

    local avatar = vgui.Create("AvatarImage", rightPanel)
    avatar:SetPos(80, 20)
    avatar:SetSize(100, 100)
    avatar:SetPlayer(LocalPlayer(), 128)

    local nameLbl = vgui.Create("DLabel", rightPanel)
    nameLbl:SetPos(0, 130)
    nameLbl:SetWide(260)
    nameLbl:SetText(LocalPlayer():Nick())
    nameLbl:SetFont("Trebuchet24")
    nameLbl:SetTextColor(colorWhite)
    nameLbl:SetContentAlignment(5)

    local balLbl = vgui.Create("DLabel", rightPanel)
    balLbl:SetPos(0, 160)
    balLbl:SetWide(260)
    balLbl:SetText(localBalance .. " Кредитів")
    balLbl:SetFont("Trebuchet24")
    balLbl:SetTextColor(colorDark)
    balLbl:SetContentAlignment(5)

    local topupBtn = vgui.Create("DButton", rightPanel)
    topupBtn:SetPos(30, 200)
    topupBtn:SetSize(200, 35)
    topupBtn:SetText("+ Поповнити баланс")
    topupBtn:SetTextColor(colorWhite)
    topupBtn.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, colorBlue)
    end
    topupBtn.DoClick = function()
        Derma_StringRequest("Поповнення", "Введіть суму (₴):", "100", function(val)
            local amt = tonumber(val)
            if amt and amt >= 10 then
                net.Start("Donatix_RequestInvoice") net.WriteUInt(amt, 32) net.SendToServer()
                f:Close()
            end
        end)
    end

    local invTitle = vgui.Create("DLabel", rightPanel)
    invTitle:SetPos(15, 250)
    invTitle:SetText("Ваш інвентар")
    invTitle:SetFont("Trebuchet18")
    invTitle:SetTextColor(colorGray)
    invTitle:SizeToContents()

    local invScroll = vgui.Create("DScrollPanel", rightPanel)
    invScroll:SetPos(10, 280)
    invScroll:SetSize(240, 310)

    if not localInventory or #localInventory == 0 then
        local empty = vgui.Create("DLabel", invScroll)
        empty:Dock(TOP) empty:SetText("Порожньо") empty:SetTextColor(colorGray) empty:SetContentAlignment(5)
    else
        for _, invItem in ipairs(localInventory) do
            local realItem = DONATIX:GetItemByID(invItem.item_id)
            if realItem then
                local p = invScroll:Add("DPanel")
                p:Dock(TOP) p:DockMargin(0, 0, 0, 5) p:SetTall(50)
                p.Paint = function(self, w, h) draw.RoundedBox(4, 0, 0, w, h, Color(240, 243, 248)) end

                local l1 = vgui.Create("DLabel", p)
                l1:SetPos(10, 5) l1:SetText(realItem.Name) l1:SetTextColor(colorDark) l1:SizeToContents()

                local btn = vgui.Create("DButton", p)
                btn:SetSize(80, 20) btn:SetPos(150, 25) btn:SetText("Активувати")
                btn:SetTextColor(colorWhite)
                btn.Paint = function(self, w, h) draw.RoundedBox(4, 0, 0, w, h, Color(46, 204, 113)) end
                btn.DoClick = function()
                    net.Start("Donatix_ActivateItem")
                    net.WriteInt(invItem.id, 32)
                    net.WriteString(realItem.ID)
                    net.SendToServer()
                end
            end
        end
    end

    -- ВЕРХНЯ ПАНЕЛЬ (Категорії / Фільтри)
    local topPanel = vgui.Create("DPanel", f)
    topPanel:Dock(TOP)
    topPanel:SetTall(50)
    topPanel:DockMargin(15, 15, 10, 0)
    topPanel.Paint = function() end

    local cats = {"Усі"}
    for _, itm in ipairs(DONATIX.ItemsList) do
        if itm.Category and not table.HasValue(cats, itm.Category) then table.insert(cats, itm.Category) end
    end

    local cx = 0
    for _, cat in ipairs(cats) do
        local btn = vgui.Create("DButton", topPanel)
        btn:SetPos(cx, 10)
        btn:SetText(cat)
        btn:SetFont("Trebuchet18")
        btn:SizeToContents()
        btn:SetWide(btn:GetWide() + 30)
        btn:SetTall(30)
        btn:SetTextColor(activeCategory == cat and colorWhite or colorBlue)
        btn.Paint = function(self, w, h)
            if activeCategory == cat then
                draw.RoundedBox(15, 0, 0, w, h, colorBlue)
            else
                draw.RoundedBox(15, 0, 0, w, h, colorWhite)
                surface.SetDrawColor(colorBlue)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
        end
        btn.DoClick = function()
            activeCategory = cat
            f:Close()
            OpenDonateMenu()
        end
        cx = cx + btn:GetWide() + 10
    end

    -- ЦЕНТРАЛЬНА ПАНЕЛЬ (Сітка товарів)
    local mainScroll = vgui.Create("DScrollPanel", f)
    mainScroll:Dock(FILL)
    mainScroll:DockMargin(15, 10, 10, 10)

    local grid = vgui.Create("DIconLayout", mainScroll)
    grid:Dock(FILL)
    grid:SetSpaceX(15)
    grid:SetSpaceY(15)

    for _, item in ipairs(DONATIX.ItemsList) do
        -- Фільтрація
        if activeCategory ~= "Усі" and item.Category ~= activeCategory then continue end
        -- Перевірка видимості
        if item.CanSee ~= nil then
            if isfunction(item.CanSee) and not item.CanSee(LocalPlayer()) then continue end
            if isbool(item.CanSee) and not item.CanSee then continue end
        end

        local pnl = grid:Add("DPanel")
        pnl:SetSize(340, 110)
        pnl.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, colorWhite)
            if item.HighlightColor then
                draw.RoundedBoxEx(8, 0, 0, 8, h, item.HighlightColor, true, false, true, false)
            end
        end

        -- Іконка або модель
        if item.IsModel and item.Icon then
            local mdl = vgui.Create("DModelPanel", pnl)
            mdl:SetPos(15, 15) mdl:SetSize(60, 60)
            mdl:SetModel(item.Icon)
            if IsValid(mdl.Entity) then
                local mn, mx = mdl.Entity:GetRenderBounds()
                local size = 0
                size = math.max(size, math.abs(mn.x) + math.abs(mx.x))
                size = math.max(size, math.abs(mn.y) + math.abs(mx.y))
                size = math.max(size, math.abs(mn.z) + math.abs(mx.z))
                mdl:SetFOV(45) mdl:SetCamPos(Vector(size, size, size)) mdl:SetLookAt((mn + mx) * 0.5)
            end
        elseif item.Icon then
            local icn = vgui.Create("DImage", pnl)
            icn:SetPos(20, 20) icn:SetSize(40, 40)
            icn:SetImage(item.Icon)
        end

        local nameLbl = vgui.Create("DLabel", pnl)
        nameLbl:SetPos(85, 10) nameLbl:SetWide(240)
        nameLbl:SetText(item.Name) nameLbl:SetFont("Trebuchet24") nameLbl:SetTextColor(colorDark)

        local descLbl = vgui.Create("DLabel", pnl)
        descLbl:SetPos(85, 35) descLbl:SetSize(240, 30)
        descLbl:SetText(item.Desc or "") descLbl:SetWrap(true) descLbl:SetTextColor(colorGray)

        -- Ціна та знижка
        if item.DiscountedFrom then
            local oldPrice = vgui.Create("DLabel", pnl)
            oldPrice:SetPos(85, 75) oldPrice:SetText(item.DiscountedFrom .. " ₴")
            oldPrice:SetTextColor(Color(231, 76, 60)) oldPrice:SizeToContents()
            
            local strike = vgui.Create("DPanel", pnl)
            strike:SetPos(85, 82) strike:SetSize(oldPrice:GetWide(), 1)
            strike.Paint = function(self, w, h) surface.SetDrawColor(231, 76, 60) surface.DrawRect(0,0,w,h) end

            local newPrice = vgui.Create("DLabel", pnl)
            newPrice:SetPos(85 + oldPrice:GetWide() + 5, 70) newPrice:SetText(item.Price .. " ₴")
            newPrice:SetFont("Trebuchet24") newPrice:SetTextColor(colorDark) newPrice:SizeToContents()
        else
            local priceLbl = vgui.Create("DLabel", pnl)
            priceLbl:SetPos(85, 70) priceLbl:SetText(item.Price .. " ₴")
            priceLbl:SetFont("Trebuchet24") priceLbl:SetTextColor(colorDark) priceLbl:SizeToContents()
        end

        local buyBtn = vgui.Create("DButton", pnl)
        buyBtn:SetSize(90, 30) buyBtn:SetPos(235, 70) buyBtn:SetText("Придбати")
        buyBtn:SetTextColor(colorWhite)
        buyBtn.Paint = function(self, w, h) draw.RoundedBox(4, 0, 0, w, h, colorBlue) end
        buyBtn.DoClick = function()
            -- Виконуємо кастомну перевірку CanBuy якщо є
            if item.CanBuy then
                local denyReason = item.CanBuy(LocalPlayer())
                if denyReason then
                    chat.AddText(Color(255,0,0), "[DONATIX] ", Color(255,255,255), denyReason)
                    return
                end
            end
            net.Start("Donatix_BuyItem") net.WriteString(item.ID) net.SendToServer()
        end
    end
end

hook.Add("OnPlayerChat", "Donatix_ChatCommand", function(ply, text)
    if text == "/donate" and ply == LocalPlayer() then
        net.Start("Donatix_RequestSync") net.SendToServer()
        OpenDonateMenu()
        return true
    end
end)