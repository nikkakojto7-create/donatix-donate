
DONATIX.ItemsList = {}

DONATIX:AddItem("root_admin")
    :SetName("Привілегія ROOT")
    :SetDescription("Повний доступ до сервера. Усі команди адміна.")
    :SetPrice(150)
    :SetDiscountedFrom(300) -- Знижка!
    :SetCategory("Привілегії")
    :SetHighlightColor(Color(231, 76, 60)) -- Червона лінія
    :SetIcon("icon16/shield.png", false)
    :SetCommand("sam setrank %STEAMID% root")

DONATIX:AddItem("vip_status")
    :SetName("VIP Статус (30 Днів)")
    :SetDescription("Доступ до VIP професій, зброї та принтерів.")
    :SetPrice(50)
    :SetCategory("Привілегії")
    :SetHighlightColor(Color(241, 196, 15)) -- Жовта лінія
    :SetIcon("icon16/star.png", false)
    :SetTerm(30)
    :SetCommand("sam setrank %STEAMID% vip")

DONATIX:AddItem("money_1kk")
    :SetName("1,000,000 ₴")
    :SetDescription("Мільйон ігрової валюти на баланс. Можна купувати багато разів.")
    :SetPrice(25)
    :SetCategory("Валюта")
    :SetHighlightColor(Color(46, 204, 113)) -- Зелена лінія
    :SetIcon("models/props/cs_assault/money.mdl", true) -- 3D Моделька
    :SetStackable(true)
    :SetOnActivate(function(ply)
        -- Виклик Lua коду замість консольної команди
        if ply.addMoney then ply:addMoney(1000000) end
        DarkRP.notify(ply, 0, 5, "Ви отримали 1,000,000 ₴!")
    end)

DONATIX:AddItem("custom_model")
    :SetName("Кастомна Модель")
    :SetDescription("Виділяйся серед натовпу! Унікальна модель гравця.")
    :SetPrice(75)
    :SetCategory("Зовнішність")
    :SetIcon("icon16/user_suit.png", false)
    :SetPerma()