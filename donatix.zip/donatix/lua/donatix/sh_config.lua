DONATIX.Config.ProjectID = 1
DONATIX.Config.SecretKey = "5e01e7bf7cb80d9988aca2dc882f4fff"
DONATIX.Config.API_URL = "https://donatix.pp.ua/"

if SERVER then
    util.AddNetworkString("Donatix_RequestInvoice")
    util.AddNetworkString("Donatix_OpenURL")
    util.AddNetworkString("Donatix_SyncData")
    util.AddNetworkString("Donatix_Notify")
    util.AddNetworkString("Donatix_BuyItem")
    util.AddNetworkString("Donatix_ActivateItem")
    util.AddNetworkString("Donatix_RequestSync") 
end