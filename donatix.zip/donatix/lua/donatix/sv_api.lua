if SERVER then
    util.AddNetworkString("Donatix_RequestInvoice")
    util.AddNetworkString("Donatix_OpenURL")
    util.AddNetworkString("Donatix_Notify")
    util.AddNetworkString("Donatix_SyncData")
    util.AddNetworkString("Donatix_RequestSync")
    util.AddNetworkString("Donatix_BuyItem")
    util.AddNetworkString("Donatix_ActivateItem")
end

local function GetBaseURL()
    local baseUrl = DONATIX.Config.API_URL
    if string.EndsWith(baseUrl, "/") then
        baseUrl = string.sub(baseUrl, 1, -2)
    end
    return baseUrl
end

local function SendNotification(ply, msg, isError)
    net.Start("Donatix_Notify")
    net.WriteString(msg)
    net.WriteBool(isError or false)
    net.Send(ply)
end


local function GetSafeSteamID(ply)
    local sid = ply:SteamID()
    -- Якщо це одиночна гра і SteamID не видався (буває "NULL" або "STEAM_ID_PENDING")
    if not sid or sid == "NULL" or sid == "STEAM_ID_PENDING" then 
        sid = "BOT_" .. ply:EntIndex() 
    end
    return sid
end


local function RegisterServerInPanel()
    local serverName = GetHostName()
    local ipPort = game.GetIPAddress() 
    if ipPort == "loopback" or ipPort == "0.0.0.0" then ipPort = "127.0.0.1:27015" end

    HTTP({
        url = GetBaseURL() .. "/api/servers/register",
        method = "POST",
        parameters = {
            project_id = tostring(DONATIX.Config.ProjectID),
            secret_key = tostring(DONATIX.Config.SecretKey),
            server_name = tostring(serverName),
            ip_port = tostring(ipPort)
        },
        success = function(code, body)
            if code == 200 then
                MsgC(Color(0, 255, 0), "[DONATIX] Сервер успішно зареєстровано!\n")
            else
                MsgC(Color(255, 0, 0), "[DONATIX] Помилка реєстрації сервера: " .. tostring(body) .. "\n")
            end
        end
    })
end
hook.Add("Initialize", "Donatix_RegisterServer", function() timer.Simple(5, RegisterServerInPanel) end)


local function SyncPlayerData(ply)
    local sid = GetSafeSteamID(ply)
    
    HTTP({
        url = GetBaseURL() .. "/api/game/sync",
        method = "POST",
        parameters = {
            project_id = tostring(DONATIX.Config.ProjectID),
            secret_key = tostring(DONATIX.Config.SecretKey),
            steamid = sid
        },
        success = function(code, body)
            if code == 200 then
                local data = util.JSONToTable(body)
                if data then
                    ply.DonatixBalance = tonumber(data.balance) or 0
                    net.Start("Donatix_SyncData")
                    net.WriteUInt(ply.DonatixBalance, 32)
                    net.WriteString(util.TableToJSON(data.inventory or {}))
                    net.Send(ply)
                    print("[DONATIX] Гравця " .. ply:Nick() .. " синхронізовано. Баланс: " .. ply.DonatixBalance)
                end
            else
                print("[DONATIX ПОМИЛКА] Синхронізація " .. ply:Nick() .. " не вдалася! Код: " .. tostring(code) .. " Відповідь: " .. tostring(body))
            end
        end,
        failed = function(err)
            print("[DONATIX ПОМИЛКА] Немає зв'язку з API при синхронізації: " .. tostring(err))
        end
    })
end
hook.Add("PlayerInitialSpawn", "Donatix_InitPlayer", SyncPlayerData)

net.Receive("Donatix_RequestSync", function(len, ply) SyncPlayerData(ply) end)


net.Receive("Donatix_RequestInvoice", function(len, ply)
    local amount = net.ReadUInt(32)
    if amount < 10 then return end

    HTTP({
        url = GetBaseURL() .. "/api/invoice/create",
        method = "POST",
        parameters = {
            project_id = tostring(DONATIX.Config.ProjectID),
            secret_key = tostring(DONATIX.Config.SecretKey),
            steamid = GetSafeSteamID(ply),
            amount = tostring(amount)
        },
        success = function(code, body)
            if code == 200 then
                local response = util.JSONToTable(body)
                if response and response.url then
                    net.Start("Donatix_OpenURL") net.WriteString(response.url) net.Send(ply)
                end
            else
                ply:ChatPrint("[DONATIX] Помилка створення рахунку. Код: " .. tostring(code))
                print("[DONATIX] Помилка рахунку: " .. tostring(body))
            end
        end
    })
end)


net.Receive("Donatix_BuyItem", function(len, ply)
    local item_id = net.ReadString()
    local item = DONATIX:GetItemByID(item_id)
    if not item then return end

    if (ply.DonatixBalance or 0) < item.Price then
        SendNotification(ply, "Недостатньо кредитів!", true) 
        return
    end

    HTTP({
        url = GetBaseURL() .. "/api/game/buy",
        method = "POST", 
        parameters = {
            project_id = tostring(DONATIX.Config.ProjectID), 
            secret_key = tostring(DONATIX.Config.SecretKey),
            steamid = GetSafeSteamID(ply), 
            item_id = tostring(item.ID), 
            price = tostring(item.Price)
        },
        success = function(code, body)
            if code == 200 then
                local data = util.JSONToTable(body)
                if data and data.success then
                    SendNotification(ply, "Успішно придбано! Перевірте інвентар.", false)
                    SyncPlayerData(ply)
                else
                    SendNotification(ply, data and data.error or "Помилка транзакції.", true)
                end
            else
                SendNotification(ply, "Помилка сервера: " .. tostring(code), true)
                print("[DONATIX ПОМИЛКА ПОКУПКИ] " .. tostring(body))
            end
        end
    })
end)


net.Receive("Donatix_ActivateItem", function(len, ply)
    local inv_id = net.ReadInt(32)
    local item_id = net.ReadString()
    local item = DONATIX:GetItemByID(item_id)
    if not item then return end


    if item.CanActivate then
        local denyReason = item.CanActivate(ply)
        if denyReason then
            SendNotification(ply, denyReason, true)
            return
        end
    end

    HTTP({
        url = GetBaseURL() .. "/api/game/activate",
        method = "POST", 
        parameters = {
            project_id = tostring(DONATIX.Config.ProjectID), 
            secret_key = tostring(DONATIX.Config.SecretKey),
            steamid = GetSafeSteamID(ply), 
            inv_id = tostring(inv_id)
        },
        success = function(code, body)
            if code == 200 then
                local data = util.JSONToTable(body)
                if data and data.success then
                    
                    -- 1. Якщо є стара добра консольна команда - виконуємо
                    if item.Command then
                        local cmd = string.Replace(item.Command, "%STEAMID%", ply:SteamID())
                        game.ConsoleCommand(cmd .. "\n")
                    end
                    
                    -- 2. Якщо є нова функція OnActivate - виконуємо
                    if item.OnActivate then
                        item.OnActivate(ply)
                    end

                    -- 3. Якщо є Installer - виконуємо
                    if item.Installer then
                        item.Installer(ply)
                    end

                    SendNotification(ply, "Предмет успішно активовано!", false)
                    SyncPlayerData(ply)
                else
                    SendNotification(ply, data and data.error or "Помилка активації.", true)
                end
            else
                print("[DONATIX ПОМИЛКА АКТИВАЦІЇ] " .. tostring(body))
                SendNotification(ply, "Помилка сервера: " .. tostring(code), true)
            end
        end,
        failed = function(err)
            print("[DONATIX ПОМИЛКА] Немає зв'язку з API: " .. tostring(err))
        end
    })
end)


hook.Add("PlayerSay", "Donatix_AddCreditsCMD", function(ply, text)
    if string.sub(text, 1, 11) == "/addcredits" then
        if not ply:IsSuperAdmin() then 
            SendNotification(ply, "У вас немає прав!", true) return "" 
        end
        local args = string.Explode(" ", text)
        local targetSteamID = args[2]
        local amount = tonumber(args[3])

        if targetSteamID and amount then
            HTTP({
                url = GetBaseURL() .. "/api/game/addcredits",
                method = "POST", 
                parameters = {
                    project_id = tostring(DONATIX.Config.ProjectID),
                    secret_key = tostring(DONATIX.Config.SecretKey),
                    steamid = targetSteamID, 
                    amount = tostring(amount)
                },
                success = function(code, body)
                    if code == 200 then
                        SendNotification(ply, "Кредити успішно видано!", false)
                        for _, v in ipairs(player.GetAll()) do
                            if GetSafeSteamID(v) == targetSteamID or v:SteamID() == targetSteamID then
                                SyncPlayerData(v)
                                SendNotification(v, "Ваш баланс поповнено адміном!", false)
                            end
                        end
                    else
                        SendNotification(ply, "Помилка видачі: " .. tostring(code), true)
                        print("[DONATIX ПОМИЛКА ВИДАЧІ] " .. tostring(body))
                    end
                end
            })
        end
        return ""
    end
end)